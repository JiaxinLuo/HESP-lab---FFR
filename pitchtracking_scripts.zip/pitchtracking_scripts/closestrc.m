function [closestv, r, c]=closestrc(M, value)
[closestva, closesti]=min(abs(M(:) - value)); % return the indices if the minimum values in the vector; the first argument refers to the mininus value 
[r,c]=ind2sub(size(M), closesti);
closestv = M(closesti);