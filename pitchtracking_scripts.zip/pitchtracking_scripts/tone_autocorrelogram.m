%% run autocorrelograms on FFRs to Mandarin tones
% This script is based on an analysis originally written by Erika Skoe (erika.skoe@uconn.edu)
% Modified by Jacie R. McHaney (jacie.mchaney@northwestern.edu), April 2024
% 
% Runs autocorrelogram on FFRs in .mat files in the following format:
% ffr: n x time ffr data for a single channel. Each row (n) is a single FFR trial that has been epoched. Each column is a sampling point in that trial.
% pol: 1 x n polarity notation (positive or negative) denoted by 1 and 2
% pre: n x prestim time to show pre stimulus information
% stim_cls: 1 x n array with class of stimuli. In the example case with mandarin tones, this is denoted by 1, 2, 3, 4

close all
clear all

%list out avg files
flist = dir('ffrfiles/*.mat');
flist = cellstr(char(flist.name));

%parameters
startAnalysis = 10; %time point to start FFT analysis
block = 40; %40ms sliding window
step = 10; %10 ms sliding steps
lags = [4,14.3]; %ms lage search in each bin
fs = 25000; %sampling rate that FFRs were recorded
tones = 1:4;
neural_lag=10;
minFrequency = 100;
maxFrequency = 350; %frequency range for autocorrelogram

%read in stimulus files and resample to same FS as eeg
stimfiles = dir('stimuli/*.wav');
stimfiles = cellstr(char(stimfiles.name));

stims = {};
for s = 1:length(stimfiles)

    [y, yFs] = audioread(['stimuli/' stimfiles{s}]);
    y2 = resample(y,fs,yFs);

    stims{s} = y2;

end



for i = 1:length(flist)

    %define file name
    fname = ['ffrfiles/' flist{i}];

    %Open average file
    file = load(fname);
    ffrall = file.ffr; %define FFR portion

    subFFT = [];

    for t=1:length(tones)
        
        clear FFT FFT_stim freqAxis freqAxis_stim autocorr autocorr_stim LAG LAG_stim time time_stim

        %get just tone of interest
        tclss = file.stim_cls;
        idx = find(tclss == t);
        ffrT = ffrall(idx,:);

        %get averaged FFR (avg of pos and neg polarities)
        ffr = mean(ffrT,1);

        %Define FFT time axis 
        xmin = 0;
        xmax = (size(ffr,2)/fs)*1000; %in ms
        pnts = size(ffr,2);
        timeaxis = linspace(xmin,xmax,pnts)';

        %get stimulus
        stim = stims{t};

        %Define stim time axis 
        xmax_stim = (size(stim,1)/fs)*1000; %in ms
        pnts_stim = size(stim,1);
        timeaxis_stim = linspace(xmin,xmax_stim,pnts_stim)';

        


        % ---------------------------PRESTIM, ---------------------------
         % extract portion of prestimulus time, and detrend. The size of the prestim portion is dependent on the block size.
         % To do SNR calculations block and prestim must the same number of ms.
         % If the block size is 40ms, then only 40ms of the prestim will be
         % extracted. 
    
         prestimAll = file.pre;
         prestimT = prestimAll(idx,:);   
         PRESTIM = mean(prestimT,1); 
    
         % ramp and detrend
         PRESTIM = detrend(PRESTIM.*hann(size(PRESTIM,2)), 'constant');  % remove the mean value from the prestim with detrend (x,'constant')
         
         % FFT (zero-padded to sampling rate);
         preFFT = abs(fft(PRESTIM, fs));  % now the frequency of FFT is up to half of the value of fs; the output are two symmetric version
         
         %scale preFFT
         preFFT= preFFT*(2./length(PRESTIM));  % scale  
         prestimFFT=preFFT(1:1001,1);  %truncate above 1000 Hz
         %plot(preFFT) %plot to check if necessary
    
    
        %  ------------------ FFTS of RESPONSE CHUNKS-----------------------
        j = startAnalysis; % each time through loop j increases by step size; this is the time point to start the analysis
    
        chunks = 5000;    % an arbitrary maximum number of blocks that the program will create. 
                            
        for k = 1:chunks;   %the loop knows to stop once xmax is exceeded 
    
            % variables created: 
            ramptime = (block/1000);   % the size of sliding window that will ramp the entire chunk; in the unit of second
            start = j;    % the starting time point for the sliding window
            stop = j+block; % the end time point for the sliding window
    
            if stop>xmax  % if stop exceeds the maximum ms time then abort and break out from loop
                k = k-1;
                j=j-step;
                break;
            else
                [val,id1] = min(abs(timeaxis-start));
                [val,id2] = min(abs(timeaxis-stop));
                signal = detrend(ffr(:,id1:id2), 'constant');   % extract a bin of the signal based on the sliding window, and then remove the mean           
            end
            
            midpoint(k) = mean(id1:id2);  %% the mid sampling point# across all the bins of the signal 
            
            % generate ramp
            ramp = hann(size(signal,1));
            
            % ramp and de-mean
            signal = detrend(signal*ramp, 'constant');
    
            % autocorrelation (see Boersma 1993)
            [c lag]=xcorr(signal, 'coeff'); % autocorrelation sequence of the signal; c -- a vector with correlations at the vector of lag (in the unit of sampling point) 
            [cwin lagwin]=xcorr(ramp, 'coeff'); % autocorrelation sequence of the ramp window; c -- a vector with correlations at the vector of lag (in the unit of sampling point) 
            LAG = linspace(-block, block, length(c)); % the lag value now in the unit of ms, and within the range of [-block, block]
            autoc=c./cwin; % this follows the step proposed in Boersma (1993); this gives the estimation of the autocorrelation of the original signal segment
            
            % only plot the first 15 ms; % lowest frequency is ~66 Hz.
            
            if block<=20
                startlag = find(LAG==0);  
                endlag = find(LAG==closestrc(LAG, 10));
                
            else
                
                startlag = find(LAG==0);  % index when LAG == 0
                endlag = find(LAG==closestrc(LAG, 15)); % index when LAG ==15
    
            end
            
            % truncate lag and r value matrices to only include values up to first 15 ms.
            autocorr(:,k)=autoc(startlag:endlag)';  % record the autocorrelation values from 0 to 15 ms lag; each column represents the results from each bin of FFR
            LAG = LAG(startlag:endlag)';
         
            ostartlag = startlag;
            
            ostoplag = endlag;
             
             %%% Now do FFTs;
            % fft, pads to sampling rate (for more info, see this link http://www.mathworks.com/help/matlab/math/fast-fourier-transform-fft.html)
            fftsignal{k} = abs(fft(signal, fs)); % return FFT with the number of points equal to fs;  using abs() to return the amplitude of the FFT result
            % only go up to 5000 Hz;
            FFT{k} = fftsignal{k}(1,1:1001);
            FFT{k}= FFT{k}*(2./length(signal)); % scale the FFT results
            freqAxis = linspace(0, 1000, 1001);
            
            j = j + step;  % loop through next time chunk; i.e., move to the next bin        
           
           
        end
        
        time = timeaxis(round(midpoint)); % the mid time points across all the bins of signal
        totalblocks = k; % how many bins
        FFT2 = FFT';
        FFT = cell2mat(FFT2); %FFT results; each column represents the results from each bin of FFR

        %get file information and save output
        subj = flist{i}(1:end-4);
        fname2 = ['processed/' subj '_Tone' num2str(t)]; 
        FFTfile = [fname2, '-FFTmatrix.mat'];
        ACfile = [fname2, '-ACmatrix.mat'];
        save(FFTfile,'FFT','freqAxis','time') %time is mid time points for all bins of the ffr signal
        save(ACfile,'autocorr','LAG','time') %autocorrs from designated time lags for all signal bins, lag values, and mid time points for all bins in the signal


        %  ------------------ FFTS of STIMULUS-----------------------
        j = 0; % each time through loop j increases by step size; this is the time point to start the analysis
    
        chunks = 5000;    % an arbitrary maximum number of blocks that the program will create. 
                            
        for k = 1:chunks;   %the loop knows to stop once xmax is exceeded 
    
            % variables created: 
            ramptime = (block/1000);   % the size of sliding window that will ramp the entire chunk; in the unit of second
            start = j;    % the starting time point for the sliding window
            stop = j+block; % the end time point for the sliding window
    
            if stop>xmax_stim  % if stop exceeds the maximum ms time then abort and break out from loop
                k = k-1;
                j=j-step;
                break;
            else
                [val,id1] = min(abs(timeaxis_stim-start));
                [val,id2] = min(abs(timeaxis_stim-stop));
                signal_stim = detrend(stim(id1:id2,:), 'constant');   % extract a bin of the signal based on the sliding window, and then remove the mean           
            end
            
            midpoint(k) = mean(id1:id2);  %% the mid sampling point# across all the bins of the signal 
            
            % generate ramp
            ramp = hann(size(signal_stim,2));
            
            % ramp and de-mean
            signal_stim = detrend(signal_stim*ramp, 'constant');
    
            % autocorrelation (see Boersma 1993)
            [c_stim lag_stim]=xcorr(signal_stim, 'coeff'); % autocorrelation sequence of the signal; c -- a vector with correlations at the vector of lag (in the unit of sampling point) 
            [cwin_stim lagwin_stim]=xcorr(ramp, 'coeff'); % autocorrelation sequence of the ramp window; c -- a vector with correlations at the vector of lag (in the unit of sampling point) 
            LAG_stim = linspace(-block, block, length(c_stim)); % the lag value now in the unit of ms, and within the range of [-block, block]
            autoc_stim=c_stim./cwin_stim; % this follows the step proposed in Boersma (1993); this gives the estimation of the autocorrelation of the original signal segment
            
            % only plot the first 15 ms; % lowest frequency is ~66 Hz.
            
            if block<=20
                startlag = find(LAG_stim==0);  
                endlag = find(LAG_stim==closestrc(LAG_stim, 10));
                
            else
                
                startlag = find(LAG_stim==0);  % index when LAG == 0
                endlag = find(LAG_stim==closestrc(LAG_stim, 15)); % index when LAG ==15
    
            end
            
            % truncate lag and r value matrices to only include values up to first 15 ms.
            autocorr_stim(:,k)=autoc_stim(startlag:endlag)';  % record the autocorrelation values from 0 to 15 ms lag; each column represents the results from each bin of FFR
            LAG_stim = LAG_stim(startlag:endlag)';
         
            ostartlag = startlag;
            
            ostoplag = endlag;
             
             %%% Now do FFTs;
            % fft, pads to sampling rate (for more info, see this link http://www.mathworks.com/help/matlab/math/fast-fourier-transform-fft.html)
            fftsignal_stim{k} = abs(fft(signal_stim, fs)); % return FFT with the number of points equal to fs;  using abs() to return the amplitude of the FFT result
            % only go up to 5000 Hz;
            FFT_stim{k} = fftsignal_stim{k}(1:1001,1);
            FFT_stim{k}= FFT_stim{k}*(2./length(signal)); % scale the FFT results
            freqAxis_stim = linspace(0, 1000, 1001);
            
            j = j + step;  % loop through next time chunk; i.e., move to the next bin        
           
           
        end
        
        time_stim = timeaxis_stim(round(midpoint)); % the mid time points across all the bins of signal
        totalblocks_stim = k; % how many bins
        FFT_stim = cell2mat(FFT_stim); %FFT results; each column represents the results from each bin of FFR




        %%%%%%%%%%%%% next is to extract the f0 contour from the stimulus and
        %%%%%%%%%%%%% FFR calculated above
        
        % Recall the stimulus and FFR are sliced into bins, now we will
        % determine the start bin # and stop bin # that will be used in
        % extracting f0 contour based on time range we specified for analysis
        
        time_stim_o=time_stim; %original time_stim
        time_stim = time_stim + neural_lag;  %for plotting purpose shift stimulus forward in time.
        
        startSTIM = 0;
        stopSTIM = (length(stim)/fs)*1000; %length of stimulus in ms
        [v stopblock_stim]=closestrc(time_stim_o, stopSTIM-((block)/2));
        [v startblock_stim]=closestrc(time_stim_o, startSTIM+(block/2));
        
        
        startRESP = startSTIM + neural_lag;
        stopRESP = stopSTIM + neural_lag;
        [v startblock]=closestrc(time, startRESP+(block/2));
        stopblock = startblock + (stopblock_stim-startblock_stim);

        %%%%%% Extract F0 using Autocorrelation Method #####################
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %stimulus f0
        freqAC_vector = 1000./LAG_stim; % calculate the F0 by taking the the reciprocal of this time-lag (changed from 1000)
        % extract the f0 within the range [minFrequency, maxFrequency]
        [val, closeid_start_stim]=min(abs(freqAC_vector(:) - maxFrequency)); % return the indices if the minimum values in the vector; the first argument refers to the mininus value 
        [LagStart_stim,c]=ind2sub(size(freqAC_vector),closeid_start_stim);
        %LagStart_stim=round(freqAC_vector(closeid_start_stim));
        Minclosestv = freqAC_vector(closeid_start_stim);

        %max freq
        [val, closeid_stop_stim]=min(abs(freqAC_vector(:) - minFrequency)); % return the indices if the minimum values in the vector; the first argument refers to the mininus value 
        [LagStop_stim,c]=ind2sub(size(freqAC_vector),closeid_stop_stim);
        maxclosestv = freqAC_vector(closeid_stop_stim);
        
        [R_stim index_stim] = max(autocorr_stim(LagStart_stim:LagStop_stim,:));
        %[R_stim index_stim] = max(autocorr_stim(100:333,:));
        FreqAC_stim=freqAC_vector(LagStart_stim+index_stim-1);
        clear index s
        
        %FFR f0
        freqAC_vector = 1000./LAG; % the range of the f0 based on the lag value (changed from 1000)
        [val, closeid_start]=min(abs(freqAC_vector(:) - maxFrequency)); % return the indices if the minimum values in the vector; the first argument refers to the mininus value 
        [LagStart,c]=ind2sub(size(freqAC_vector),closeid_start);
        closestv = freqAC_vector(closeid_start);

        [val, closeid_stop]=min(abs(freqAC_vector(:) - minFrequency)); % return the indices if the minimum values in the vector; the first argument refers to the mininus value 
        [LagStop,c]=ind2sub(size(freqAC_vector),closeid_stop);
        closestv = freqAC_vector(closeid_stop);
        
        
        [R index] = max(autocorr(LagStart:LagStop,:)); % first locate the autocorrelations values that are within the lag range [lagstart lagstop] across all the bins; then find the peak autocorrelation and its index in each bin
        FreqAC=freqAC_vector(LagStart+index-1); % find the frequency value
        LAG2 = 1000./FreqAC; % compute the value
        
        % extract the R value at the stimulus maximum. For all subjects, the
        % same point will be evaluated.
        %     autocorr_trunc = autocorr(:, startblock:stopblock);
       
        index_stim = index_stim(startblock_stim:stopblock_stim);
        for m = 1:length(index_stim)-1
            [R_fromStimF0(m)]= autocorr(index_stim(m), m);
        end

        %%%%%% Extract F0 using FFT #####################
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %stimulus F0
        
        [FFTAMP_stim index_stim]= max(FFT_stim(minFrequency+1:maxFrequency+1, :));
        FreqFFT_stim = minFrequency+index_stim-1;
        
        %response F0
        [MaxFFTAMP index]= max(FFT(:,minFrequency+1:maxFrequency+1));
        FreqFFT = (minFrequency+index-1)'; %flip direction so that it matches FreqAC
        %The amplitude at the Stimulus frequency.  The same point(Frequency)
        %will be evalutated for al subjects.
        FFT_trunc = FFT(startblock:stopblock-1,:);
        index_stim = index_stim(startblock_stim:stopblock_stim);
        for m = 1:length(index_stim)-1;
            FreqFFT_fromStimF0(m) = FFT_trunc(m,minFrequency+index_stim(m)+1);
        end


        for e = 1:totalblocks
            F0_AMPusingACfreq(e,1) = FFT(e,round(FreqAC(e))-1);
        end

        mean_F0_AMP = mean(F0_AMPusingACfreq(startblock:startblock,1));
        F0_AMP_prestim = prestimFFT(round(FreqAC)-1);
        PITCH_SNR = F0_AMPusingACfreq./F0_AMP_prestim(startblock:startblock);
        
        
        %Determine whether the extracted frequency was also the spectral maximum
        for e = 1:totalblocks;
            peaks{e}=localmax(FFT(e,:));  %Find amplitude using frequencies extracted using AC method
            [closest_spectralpeak(e) row(e) column(e)]=closestrc(peaks{e}, FreqAC(e));
            
            [v maxFFT]=max(FFT(e,:));
            if  maxFFT-1==(closest_spectralpeak(e)-1)
                notspectralMax(e) = 0;
            else
                notspectralMax(e) = 1;
            end
            
            
        end

        total_notatSpectralMax = sum(notspectralMax(startblock:startblock));
        plot_notatspectralMax(notspectralMax==1)=maxFrequency+5;
        plot_notatspectralMax(notspectralMax==0)=NaN;
        
        
        plot_belowNF(PITCH_SNR<1)=maxFrequency+4;
        plot_belowNF(PITCH_SNR>=1)=NaN;

        %% calculate final measures
        stopblock = stopblock-1;
        stopblock_stim = stopblock_stim-1;
        PITCH_ERROR = mean(abs(FreqAC(startblock:stopblock)-FreqAC_stim(startblock_stim:stopblock_stim)));  %Measured in Hz.
        CORR = corrcoef(FreqAC(startblock:stopblock), FreqAC_stim((startblock_stim:stopblock_stim)));  %straight correlation between stimulus and response f0 contour
        [CR_CORR_N,CR_LAGS_N] = xcorr(FreqAC(startblock:stopblock), FreqAC_stim(startblock_stim:stopblock_stim),'coeff');  %cross-correlation between stimulus and response f0 contour
        [CR_CORR,CR_LAGS] = xcorr(FreqAC(startblock:stopblock), FreqAC_stim((startblock_stim:stopblock_stim)));
        %detrend version
        FreqAC_drd = detrend(FreqAC(startblock:stopblock), 'constant');
        FreqAC_stim_drd = detrend(FreqAC_stim(startblock_stim:stopblock_stim), 'constant');
        [CR_CORR_N_DRD,CR_LAGS_N_DRD] = xcorr(FreqAC_drd, FreqAC_stim_drd,'coeff');  %cross-correlation between stimulus and response f0 contour
        

        % Pearson correlation
        PITCH_SRCORR =CORR(1,2); %the first number is always 1, need to take second
        % normalized version
        [PITCH_SRCORR_CR_N,I_N] = max(CR_CORR_N);% find the max positive cross-correlation value
         lagDiff_N = CR_LAGS(I_N);
        %un-normalized version
        [PITCH_SRCORR_CR,I] = max(CR_CORR);% find the max positive cross-correlation value
        lagDiff = CR_LAGS(I); % the lag the has the max positive cross-correlation value
        % detrend & normalized version
        [PITCH_SRCORR_CR_N_DRD,I_N_DRD] = max(abs(CR_CORR_N_DRD));% find the max positive cross-correlation value
         lagDiff_N_DRD = CR_LAGS(I_N_DRD);
        
        PITCH_STRENGTH = mean(R(startblock:stopblock)); % average the peak autocorrelation
        STRENGTH_usingSTIMMAX = mean(R_fromStimF0);
        meanAmp_fromStimF0 = mean(FreqFFT_fromStimF0);
        
        total_belowNF =  sum(PITCH_SNR(startblock:stopblock)<1);
        total_notatSpectralMax = sum(notspectralMax(startblock:stopblock));

        
        % plot subject autocorrelograms
        h = figure;
        set(gcf, 'color', 'w');

        RespContour = FreqAC;
        StimContour = FreqAC_stim;
        t2 = 'Frequency Contour: AC Method';
        
        colormap('jet')
        orient landscape
        subplot(2,2,1);
        plot(time(startblock:stopblock), RespContour(startblock:stopblock), 's', 'color',  [1 0.7  0], 'MarkerFaceColor', 'y',  'MarkerSize', 6);
        hold on;
        plot(time_stim(startblock_stim:stopblock_stim), StimContour(startblock_stim:stopblock_stim), 'k', 'LineWidth', 2);
        xlabel('Time (ms)', 'FontSize',12);
        ylabel('Frequency (Hz)', 'FontSize',12);
        set(gca, 'FontSize', 10);
        ylim([min(FreqAC)-20 max(FreqAC)+20])
        hold on;
        plot(time(startblock:stopblock), plot_belowNF(startblock:stopblock), '*', 'color', [0.8 0.8 0.8], 'MarkerSize', 2 );
        plot(time(startblock:stopblock), plot_notatspectralMax(startblock:stopblock), '*', 'color', 'r', 'MarkerFaceColor', 'r', 'MarkerSize', 2);
        xlim([time(startblock) time(stopblock)]);
        title([t, '   ' 'Error = ',   num2str(fixdec(PITCH_ERROR,2))], 'FontSize', 12);
        h = legend('Response', 'Stimulus', 'below Noise Floor', 'Not Spectral Max', 'Location', 'SouthWest');
        set(h, 'FontSize', 6);
        set(gca, 'Box', 'off');
        
        subplot(2,2,2);
        imagesc(time, lag, autocorr);
        c= colorbar;
        
        set(c, 'FontSize', 8);
        set(get(c,'ylabel'),'string', 'Autocorrelation (r)'); 
        set(c, 'Position', [0.858 0.581 0.0438 0.341]);
        set(gca, 'Box', 'off');
        ylabel('Lag (ms)', 'FontSize', 12);
        set(gca, 'FontSize', 10); hold on;
        plot([time(startblock)  time(startblock)], [-50 50], 'w:', 'LineWidth', 3)
        plot([time(stopblock)  time(stopblock)], [-50 50], 'w:', 'LineWidth', 3)
        hold on;
        plot(time(1:stopblock), LAG2, 'b.', 'MarkerSize', 4);
        caxis([-1 1]);
        xlim([time(1) time(end)]);
        ylim([lag(1) lag(end)])
        title('Running Autocorrelogram with Pitch Track', 'FontSize', 9);
        set(gca, 'Position', [0.57 0.581  0.2670    0.341]);  %the plot is squished when the colorbar is added, this resets subplot to the original size.
        
        
        suptitle(fname); %need to add overall title before adding the legend.  This is a bug in suptitle.
        
        
        subplot(2,2,3);
        FFT_cut = (FFT(:,1:1001));
        % FFT_cut(FFT_cut<15)=NaN;  %only plot amplitudes above 15
        imagesc(time, 1:1001, FFT_cut); hold on;
        plot(time(1:stopblock), RespContour, 'b.', 'MarkerSize', 4);
        xlabel('Time (ms)', 'FontSize', 12);
        ylabel('Frequency (Hz)', 'FontSize', 12);
        set(gca, 'FontSize', 10);
        set(gca, 'YDir', 'normal');
        xlim([time(1) time(end)]);
        ylim([1 1000 ]);
        plot([time(startblock)  time(startblock)], [0 1000], 'w:', 'LineWidth', 3)
        plot([time(stopblock)  time(stopblock)], [0 1000], 'w:', 'LineWidth', 3)
        title('Running FFT', 'FontSize', 12);
        % set(gca, 'Position', [0.57 0.11 0.2670    0.341]);
        c=colorbar('Location', 'EastOutside' );
        set(c, 'FontSize', 8);
        set(get(c,'ylabel'),'string',[char(181), 'V']); 
        hold on;
        
        set(gca, 'Box', 'off');

        figname = ['figures/' subj '_Tone_' num2str(t) '_figures.png'];
        
        saveas(gcf,figname);


    
    end %tones

end


